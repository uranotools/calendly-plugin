var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Engine/CalendlyEnginePlugin.ts
var CalendlyEnginePlugin_exports = {};
__export(CalendlyEnginePlugin_exports, {
  CalendlyEnginePlugin: () => CalendlyEnginePlugin
});
module.exports = __toCommonJS(CalendlyEnginePlugin_exports);
var import_EnginePluginBase = require("@core/EnginePluginBase");
var CalendlyEnginePlugin = class extends import_EnginePluginBase.EnginePluginBase {
  constructor(config) {
    super(config);
    this.config = config;
  }
  async onSessionStart(ctx) {
    const mode = this.config?.PLUGIN_MODE || "full";
    ctx.appendCustomInstructions(
      `

[\u{1F512} M\xD3DULO CALENDLY - CONFIGURACI\xD3N DEL SISTEMA]
El plugin de Calendly est\xE1 configurado por el usuario en el modo: "${mode}".
Como agente, debes respetar estrictamente las siguientes restricciones y limitaciones en este chat:
` + (mode === "readonly" ? `* Est\xE1s en modo de SOLO LECTURA. Solo puedes consultar y listar informaci\xF3n. TIENES PROHIBIDO cancelar reuniones, generar links de agendamiento o crear/eliminar webhooks.
` : "") + (mode === "scheduling_only" ? `* Est\xE1s en modo de SOLO AGENDAMIENTO. Solo puedes consultar la disponibilidad del usuario y generar links de agendamiento. TIENES PROHIBIDO listar eventos agendados, consultar invitados, cancelar eventos o administrar webhooks.
` : "") + `* Si el usuario te pide realizar alguna de estas acciones prohibidas, expl\xEDcale de forma cort\xE9s que no puedes hacerlo porque el plugin est\xE1 configurado en el modo "${mode}", e ind\xEDcale que puede cambiar el modo en la configuraci\xF3n (MCP Manager \u2192 Calendly \u2192 Configuraci\xF3n).`
    );
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CalendlyEnginePlugin
});
